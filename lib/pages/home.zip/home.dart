// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height / 3,
                decoration: BoxDecoration(
                  // borderRadius: BorderRadius.circular(6.0),
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      Color.fromRGBO(28, 89, 178, 1.0),
                      Color.fromRGBO(19, 79, 159, 1.0)
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  color: Color.fromRGBO(245, 248, 255, 1.0),
                ),
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              30.0,
              0,
              0,
              210.0,
            ),
            child: Align(
              alignment: Alignment.center,
              child: Container(
                height: 130.0,
                color: Colors.transparent,
                child: ListView.builder(
                  // padding: EdgeInsets.only(left: Regular_margin_size),
                  scrollDirection: Axis.horizontal,
                  itemCount: 10,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 16.0),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                            8.0,
                          ),
                          color: Color.fromRGBO(
                            26,
                            105,
                            200,
                            1.0,
                          ),
                        ),
                        // height: 115.0,
                        width: 260.0,
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Office No.248/3 patients",
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(
                                height: 12.0,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      right: 8.0,
                                    ),
                                    child: Icon(
                                      Icons.access_time,
                                      color: Colors.white,
                                      size: 18.0,
                                    ),
                                  ),
                                  Text(
                                    "8:30 AM - 02:00 PM",
                                    style: TextStyle(
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 12.0,
                              ),
                              Row(
                                children: [
                                  Container(
                                    height: 28.0,
                                    child: ListView.builder(
                                      itemCount: 3,
                                      physics: NeverScrollableScrollPhysics(),
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      itemBuilder:
                                          (BuildContext context, index) {
                                        return Padding(
                                          padding: const EdgeInsets.only(
                                            right: 8.0,
                                          ),
                                          child: CircleAvatar(
                                            radius: 15.0,
                                            backgroundImage: NetworkImage(
                                                "https://avatoon.me/wp-content/uploads/2020/07/Cartoon-Pic-Ideas-for-DP-Profile07.png"),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  Spacer(),
                                  Container(
                                    height: 26.0,
                                    width: 26.0,
                                    decoration: BoxDecoration(
                                      color: Color.fromRGBO(
                                        91,
                                        158,
                                        249,
                                        1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(13.0),
                                    ),
                                    child: Icon(
                                      Icons.check,
                                      color: Colors.white,
                                    ),
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: MediaQuery.of(context).size.height / 2,
              // color: Colors.red,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 30.0,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text("Time"),
                        SizedBox(
                          width: 20.0,
                        ),
                        VerticalDivider(
                            width: 20.0, thickness: 10.0, color: Colors.black),
                        Text("Events"),
                        SizedBox(
                            // height: 20.0,
                            )
                      ],
                    ),
                    Container(
                      height: MediaQuery.of(context).size.height / 2.4,
                      child: ListView.builder(
                          shrinkWrap: true,
                          itemCount: 10,
                          itemBuilder: (BuildContext context, index) {
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "8:00",
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    20.0,
                                    20.0,
                                    0.0,
                                    0,
                                  ),
                                  child: Container(
                                    height: 75.0,
                                    width: 220.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(15.0),
                                    ),
                                  ),
                                )
                              ],
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
