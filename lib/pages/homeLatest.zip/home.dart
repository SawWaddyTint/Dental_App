// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, prefer_const_constructors_in_immutables, use_key_in_widget_constructors

import 'package:dental_app/bloc/home_bloc.dart';
import 'package:dental_app/data/vos/time_vo.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) => HomeBloc(),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 3,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.circular(6.0),
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Color.fromRGBO(28, 89, 178, 1.0),
                        Color.fromRGBO(19, 79, 159, 1.0)
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    color: Color.fromRGBO(245, 248, 255, 1.0),
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                30.0,
                0,
                0,
                210.0,
              ),
              child: Align(
                alignment: Alignment.center,
                child: Container(
                  height: 130.0,
                  color: Colors.transparent,
                  child: ListView.builder(
                    // padding: EdgeInsets.only(left: Regular_margin_size),
                    scrollDirection: Axis.horizontal,
                    itemCount: 10,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 16.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              8.0,
                            ),
                            color: Color.fromRGBO(
                              26,
                              105,
                              200,
                              1.0,
                            ),
                          ),
                          // height: 115.0,
                          width: 260.0,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Office No.248/3 patients",
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(
                                  height: 12.0,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        right: 8.0,
                                      ),
                                      child: Icon(
                                        Icons.access_time,
                                        color: Colors.white,
                                        size: 18.0,
                                      ),
                                    ),
                                    Text(
                                      "8:30 AM - 02:00 PM",
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 12.0,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      height: 28.0,
                                      child: ListView.builder(
                                        itemCount: 3,
                                        physics: NeverScrollableScrollPhysics(),
                                        scrollDirection: Axis.horizontal,
                                        shrinkWrap: true,
                                        itemBuilder:
                                            (BuildContext context, index) {
                                          return Padding(
                                            padding: const EdgeInsets.only(
                                              right: 8.0,
                                            ),
                                            child: CircleAvatar(
                                              radius: 15.0,
                                              backgroundImage: NetworkImage(
                                                  "https://avatoon.me/wp-content/uploads/2020/07/Cartoon-Pic-Ideas-for-DP-Profile07.png"),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    Spacer(),
                                    Container(
                                      height: 24.0,
                                      width: 24.0,
                                      decoration: BoxDecoration(
                                        color: Color.fromRGBO(
                                          91,
                                          158,
                                          249,
                                          1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                      ),
                                      child: Icon(
                                        Icons.check,
                                        color: Colors.white,
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            // Align(
            //   alignment: Alignment.bottomCenter,
            //   child: Container(
            //     height: MediaQuery.of(context).size.height / 2,
            //     // color: Colors.red,
            //     child: Padding(
            //       padding: const EdgeInsets.only(
            //         left: 30.0,
            //       ),
            //       child: Column(
            //         mainAxisAlignment: MainAxisAlignment.start,
            //         children: [
            //           Row(
            //             children: [
            //               Text("Time"),
            //               SizedBox(
            //                 width: 20.0,
            //               ),
            //               VerticalDivider(
            //                 thickness: 0.5,
            //                 width: 20,
            //                 color: Colors.black,
            //               ),
            //               Text("Events"),
            //               SizedBox(
            //                   // height: 20.0,
            //                   )
            //             ],
            //           ),
            //           Container(
            //             height: MediaQuery.of(context).size.height / 2.4,
            //             child: ListView.builder(
            //                 shrinkWrap: true,
            //                 itemCount: 10,
            //                 itemBuilder: (BuildContext context, index) {
            //                   return IntrinsicHeight(
            //                     child: Row(
            //                       crossAxisAlignment: CrossAxisAlignment.start,
            //                       children: [
            //                         Text(
            //                           "8:00",
            //                         ),
            //                         VerticalDivider(
            //                           thickness: 0.5,
            //                           width: 20,
            //                           color: Colors.black,
            //                         ),
            //                         Padding(
            //                           padding: const EdgeInsets.fromLTRB(
            //                             20.0,
            //                             20.0,
            //                             0.0,
            //                             0,
            //                           ),
            //                           child: Container(
            //                             height: 75.0,
            //                             width: 220.0,
            //                             decoration: BoxDecoration(
            //                               color: Colors.white,
            //                               borderRadius:
            //                                   BorderRadius.circular(15.0),
            //                             ),
            //                           ),
            //                         )
            //                       ],
            //                     ),
            //                   );
            //                 }),
            //           ),
            //         ],
            //       ),
            //     ),
            //   ),
            // )
            // Align(
            //   alignment: Alignment.bottomCenter,
            //   child: Padding(
            //     padding: const EdgeInsets.only(
            //       left: 30.0,
            //     ),
            //     child: IntrinsicHeight(
            //       child: Row(
            //         mainAxisAlignment: MainAxisAlignment.start,
            //         children: [
            //           Container(
            //             width: 40.0,
            //             height: MediaQuery.of(context).size.height / 2,
            //             child: Column(
            //               crossAxisAlignment: CrossAxisAlignment.start,
            //               children: [
            //                 Text(
            //                   "Time",
            //                 ),
            //                 SizedBox(
            //                   height: 10.0,
            //                 ),
            //                 Container(
            //                   height: MediaQuery.of(context).size.height / 2.4,
            //                   child: ListView.builder(
            //                     shrinkWrap: true,
            //                     itemCount: 10,
            //                     scrollDirection: Axis.vertical,
            //                     itemBuilder: (BuildContext context, index) {
            //                       return Padding(
            //                         padding: const EdgeInsets.only(bottom: 30.0),
            //                         child: Text(
            //                           "8:00",
            //                         ),
            //                       );
            //                     },
            //                   ),
            //                 )
            //               ],
            //             ),
            //           ),
            //           VerticalDivider(
            //             thickness: 0.5,
            //             color: Colors.black,
            //           ),
            //         ],
            //       ),
            //     ),
            //   ),
            // )
            Positioned(
              top: 300,
              left: 0,
              height: 2000.0,
              width: MediaQuery.of(context).size.width,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 30.0,
                        ),
                        SizedBox(
                          width: 50.0,
                          child: Text(
                            "Time",
                            style: TextStyle(
                              color: Color.fromRGBO(
                                96,
                                99,
                                104,
                                1.0,
                              ),
                              fontSize: 16.0,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        DrawDottedLine(60.0),
                        // SizedBox(
                        //   width: 20.0,
                        // ),
                        Padding(
                          padding: const EdgeInsets.only(left: 30.0),
                          child: Text(
                            "Events",
                            style: TextStyle(
                              color: Color.fromRGBO(
                                96,
                                99,
                                104,
                                1.0,
                              ),
                              fontSize: 16.0,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Selector<HomeBloc, List<TimeVO>?>(
                        selector: (context, bloc) => bloc.timeData1,
                        builder: (BuildContext context, timeData1, child) {
                          return Container(
                            height: 300.0,
                            child: ListView.builder(
                              padding: EdgeInsets.zero,
                              itemCount: timeData1?.length,
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              itemBuilder: (BuildContext context, int index) {
                                return Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      width: 30.0,
                                    ),
                                    SizedBox(
                                      width: 50.0,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            timeData1?[index].startTime ?? "",
                                          ),
                                          SizedBox(
                                            height: 40.0,
                                          ),
                                          Text(
                                            timeData1?[index].endTime ?? "",
                                          ),
                                          SizedBox(
                                            height: 35.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    (timeData1 != null &&
                                            timeData1[index].isCurrentTime)
                                        ? DrawLine(
                                            110,
                                          )
                                        : DrawDottedLine(
                                            120,
                                          ),
                                    (timeData1 != null &&
                                            timeData1[index].showCircle)
                                        ? Container(
                                            height: 16.0,
                                            width: 16.0,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.3),
                                                  spreadRadius: 2,
                                                  blurRadius: 2,
                                                  offset: Offset(0,
                                                      1), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Center(
                                              child: Container(
                                                height: 10.0,
                                                width: 10.0,
                                                decoration: BoxDecoration(
                                                  color: Color.fromRGBO(
                                                      19, 79, 159, 1.0),
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(
                                            color: Colors.transparent,
                                            height: 16.0,
                                            width: 16.0,
                                          ),
                                    (timeData1 != null &&
                                            timeData1[index].isCurrentTime)
                                        ? Flexible(
                                            child: Container(
                                              width: double.infinity,
                                              color: Color.fromRGBO(
                                                  221, 231, 249, 1.0),
                                              height: 120.0,
                                              child: Container(
                                                height: 40.0,
                                                width: 220.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.red,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15.0),
                                                ),
                                              ),
                                            ),
                                          )
                                        : Flexible(
                                            child: Container(
                                              width: double.infinity,
                                              color: Color.fromRGBO(
                                                  245, 248, 255, 1.0),
                                              height: 120.0,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        0, 0, 10, 30),
                                                child: Container(
                                                  height: 40.0,
                                                  width: 220.0,
                                                  decoration: BoxDecoration(
                                                    color: Colors.red,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15.0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                  ],
                                );
                              },
                            ),
                          );
                        }),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class DrawDottedLine extends StatelessWidget {
  final double height;
  DrawDottedLine(this.height);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      // Change to your preferred size.
      // Width and height will be used under "paint" method below.
      // The canvas accesses it by using size.width, size.height
      height: height,
      width: 0,
      child: CustomPaint(
        painter: DottedLinePainter(),
      ),
    );
  }
}

class DottedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    double dashHeight = 5, dashSpace = 5, startY = 0;
    final paint = Paint()
      ..color = Color.fromRGBO(
        96,
        99,
        104,
        1.0,
      )
      ..strokeWidth = 1.8;
    while (startY < size.height) {
      canvas.drawLine(Offset(8, startY), Offset(8, startY + dashHeight), paint);
      startY += dashHeight + dashSpace;
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class DrawLine extends StatelessWidget {
  final double height;
  DrawLine(this.height);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      // Change to your preferred size.
      // Width and height will be used under "paint" method below.
      // The canvas accesses it by using size.width, size.height
      height: height,
      width: 0,
      child: CustomPaint(
        painter: LinePainter(),
      ),
    );
  }
}
// class DrawLine extends StatelessWidget {
//   final double height;
//   DrawLine(this.height);
//   @override
//   Widget build(BuildContext context) {
//     return Stack(
//       children: [
//         Positioned.fill(
//             child: Expanded(
//           child: Container(
//             width: 230,
//             height: 300,
//             color: Colors.red,
//           ),
//         )),
//         SizedBox(
//           // Change to your preferred size.
//           // Width and height will be used under "paint" method below.
//           // The canvas accesses it by using size.width, size.height
//           height: height,
//           width: 0,
//           child: CustomPaint(
//             painter: LinePainter(),
//           ),
//         ),
//         Container(
//           height: 16.0,
//           width: 16.0,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             shape: BoxShape.circle,
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.grey.withOpacity(0.3),
//                 spreadRadius: 2,
//                 blurRadius: 2,
//                 offset: Offset(0, 1), // changes position of shadow
//               ),
//             ],
//           ),
//           child: Center(
//             child: Container(
//               height: 10.0,
//               width: 10.0,
//               decoration: BoxDecoration(
//                 color: Color.fromRGBO(19, 79, 159, 1.0),
//                 shape: BoxShape.circle,
//               ),
//             ),
//           ),
//         )
//       ],
//     );
//   }
// }

class LinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color.fromRGBO(
        96,
        99,
        104,
        1.0,
      )
      ..strokeWidth = 0.6;
    final p1 = Offset(8, -6);
    final p2 = Offset(8, 150);
    canvas.drawLine(p1, p2, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
